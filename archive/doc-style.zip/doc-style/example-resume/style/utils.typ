// Layout mechanics — shared helpers, render functions, and the component factory.
//
// Imported by layout.typ (and any future style modules that need the same machinery).
// All names here are intended to be called from other style files; they have no
// leading underscore.

// No per-call or per-component overrides for typography fundamentals like scale,
// font-profile, or measure. Those are configured once at `layout.make()` time.
// Per-call args are only style tweaks (weight, fill, size, tracking, etc.).
#let _meta-keys = ()

#let filter-auto(d) = {
  let r = (:)
  for (k, v) in d {
    if v != auto { r.insert(k, v) }
  }
  r
}

#let split-meta(d) = {
  let meta = (:)
  let real = (:)
  for (k, v) in d {
    if _meta-keys.contains(k) { meta.insert(k, v) }
    else { real.insert(k, v) }
  }
  (meta: meta, real: real)
}

#let compute(step, scale, font, measure) = {
  let size = (scale.size)(step)
  (
    size: size,
    tracking: (font.tracking)(size),
    spacing: (font.word-space)(size),
    leading: (font.leading)(size, measure: measure),
  )
}

// ─── Render functions ──────────────────────────────────────────────────────────
// Each render takes the fully-resolved param dict and the body, extracts its own
// decoration-specific keys, and delegates remaining text/par keys to render-text.

// Par-level keys we recognize in the final dict. Extracted before passing to text().
#let _par-keys = ("leading", "justify", "first-line-indent", "hanging-indent", "linebreaks")

#let render-text(final, body) = {
  let f = final
  let par-args = (:)
  for k in _par-keys {
    if k in f { par-args.insert(k, f.remove(k)) }
  }
  if par-args.len() > 0 {
    [
      #set par(..par-args)
      #text(..f, body)
    ]
  } else {
    text(..f, body)
  }
}

#let render-link(final, body) = {
  let f = final
  let dest = if "dest" in f { f.remove("dest") } else { none }
  let stroke = if "underline-stroke" in f { f.remove("underline-stroke") } else { auto }
  let offset = if "underline-offset" in f { f.remove("underline-offset") } else { auto }
  let inner = render-text(f, body)
  let decorated = underline(stroke: stroke, offset: offset, inner)
  if dest != none { link(dest, decorated) } else { decorated }
}

// Extract block-* prefixed keys and return (extracted-args, remaining-dict).
// Recognized: block-fill, block-stroke, block-inset, block-radius, block-width,
// block-height, block-breakable, block-outset, block-clip, block-above, block-below.
// Mutates a local copy and returns it — caller receives the modified dict.
#let extract-block-args(f) = {
  let args = (:)
  let keys = (
    "fill", "stroke", "inset", "radius", "width", "height",
    "breakable", "outset", "clip", "above", "below",
  )
  for k in keys {
    let our-key = "block-" + k
    if our-key in f { args.insert(k, f.remove(our-key)) }
  }
  (args, f)
}

#let render-code-block(final, body) = {
  let (block-args, f) = extract-block-args(final)
  let inner = render-text(f, body)
  block(breakable: true, width: 100%, ..block-args, inner)
}

#let render-quote(final, body) = {
  let (block-args, f) = extract-block-args(final)
  let attribution = if "attribution" in f { f.remove("attribution") } else { none }
  // Typst's quote element passes `quotes:` through; drop it so it doesn't reach text().
  if "quotes" in f { let _ = f.remove("quotes") }
  if not "inset" in block-args { block-args.insert("inset", (left: 2em)) }
  let composed = if attribution != none {
    [#body \ #h(1fr) — #attribution]
  } else {
    body
  }
  let inner = render-text(f, composed)
  block(..block-args, inner)
}

#let render-figure-caption(final, body) = {
  let f = final
  let alignment = if "align" in f { f.remove("align") } else { center }
  let inner = render-text(f, body)
  align(alignment, inner)
}

#let render-list(final, body) = {
  let f = final
  let list-args = (:)
  for k in ("tight", "marker", "indent", "body-indent") {
    if k in f { list-args.insert(k, f.remove(k)) }
  }
  if "list-spacing" in f { list-args.insert("spacing", f.remove("list-spacing")) }
  let par-args = (:)
  if "leading" in f { par-args.insert("leading", f.remove("leading")) }
  [
    #set list(..list-args)
    #set par(..par-args)
    #text(..f, body)
  ]
}

#let render-enum(final, body) = {
  let f = final
  let enum-args = (:)
  for k in ("tight", "numbering", "start", "full", "indent", "body-indent") {
    if k in f { enum-args.insert(k, f.remove(k)) }
  }
  if "list-spacing" in f { enum-args.insert("spacing", f.remove("list-spacing")) }
  let par-args = (:)
  if "leading" in f { par-args.insert("leading", f.remove("leading")) }
  [
    #set enum(..enum-args)
    #set par(..par-args)
    #text(..f, body)
  ]
}

#let render-figure(final, body) = {
  let f = final
  let caption = if "caption" in f { f.remove("caption") } else { none }
  let fig-args = (:)
  for k in ("kind", "supplement", "numbering", "placement", "gap", "outlined") {
    if k in f { fig-args.insert(k, f.remove(k)) }
  }
  if caption != none { fig-args.insert("caption", figure.caption(caption)) }
  let styled-body = render-text(f, body)
  figure(styled-body, ..fig-args)
}

#let render-divider(final, body) = {
  let stroke = final.at("stroke", default: 0.5pt)
  let length = final.at("length", default: 100%)
  line(length: length, stroke: stroke)
}

// ─── Component factory ─────────────────────────────────────────────────────────
// Builds a callable that resolves overrides at three layers (built-in defaults,
// per-component overrides, per-call args), handles meta-key recomputation, and
// dispatches to the spec's render function.

#let make-component(state, spec, comp-overrides) = {
  let step = spec.step
  let base-defaults = spec.defaults + filter-auto(comp-overrides)
  let computed = if step == none {
    (:)
  } else {
    compute(step, state.scale, state.font, state.measure)
  }
  let comp-base = computed + base-defaults

  (..args) => {
    let body = args.pos().at(0, default: [])
    let cleaned-call = filter-auto(args.named())
    let final = comp-base + cleaned-call
    (spec.render)(final, body)
  }
}
